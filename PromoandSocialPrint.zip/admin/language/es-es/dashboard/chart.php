<?php
// Heading
$_['heading_title'] = 'An&aacute;lisis de Ventas';

// Text
$_['text_order']    = 'Pedidos';
$_['text_customer'] = 'Clientes';
$_['text_day']      = 'Hoy';
$_['text_week']     = 'Semana';
$_['text_month']    = 'Mes';
$_['text_year']     = 'A&ntilde;o';