<?php
// Heading
$_['heading_title'] = 'Total de Clientes';

// Text
$_['text_view'] = 'Ver m&aacute;s...';