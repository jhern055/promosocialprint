<?php
// Heading
$_['heading_title'] = 'Total de Pedidos';

// Text
$_['text_view']     = 'Ver m&aacute;s...';