<?php
// Text
$_['text_footer'] 	= '<a href="http://wuam.es">Wuam</a> &copy; 2004-' . date('Y') . ' Todos los derechos reservados.';
$_['text_version'] 	= 'Versi&oacute;n %s';