<?php
$_['text_complete_status']   = 'Pedidos Completos'; 
$_['text_processing_status'] = 'Pedidos Procesandose'; 
$_['text_other_status']      = 'Otros Estados'; 