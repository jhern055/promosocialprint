<?php
// Heading
$_['heading_title']       = '<b style="color:#428bca">Journal 2</b>';

?>